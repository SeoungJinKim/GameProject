#pragma once
#include "Game2D.h"
#include <ctime>
#include <random>
#include "Star.h"

namespace jm
{
	class Box
	{
	public:
		vec2 center;
		float start_x, finish_x, start_y, finish_y;
		bool hit = false;
		bool delete_star = false;
		Star *star = nullptr;
		
	public:
		Box()
		{
			star = new Star;
			std::random_device rd;
			std::mt19937 mersenne(rd());
			std::uniform_real_distribution<> rand_x(0, 3.2);
			std::uniform_real_distribution<> rand_y(0, 1.2f);

			beginTransformation();
			{
				float temp = (float)rand_x(mersenne) - 1.5f; // [-1.5f,1.7f] ���� �߻�
				center.x = temp;
				start_x = temp - 0.084f;
				finish_x = temp + 0.084f;
				temp = (float)rand_y(mersenne) - 0.4f; // [-0.4f,0.8f] ���� �߻�
				center.y = temp;
				start_y = temp - 0.084f;
				finish_y = temp + 0.084f;
			}
			endTransformation();
		}
		~Box()
		{
		}
	};
}