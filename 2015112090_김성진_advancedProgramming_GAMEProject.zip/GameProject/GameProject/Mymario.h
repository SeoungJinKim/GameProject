#pragma once
#include "Game2D.h"


namespace jm {
	class Mario : public Game2D
	{
	public:
		float head, foot, front, back; // ĳ������ �� �κе�
		vec2 start_pos = vec2(-1.7f, -0.34f); // ĳ���� ���� ��ġ
		vec2 center = vec2(0.0f, -0.14f); // ĳ������ �߽�(���� ��ġ�κ���)
		vec2 center_box = vec2(0.0f, 0.02f); // ĳ������ �߽����� ���� ������ �׵θ� �ڽ��� �߽�
		vec2 face_center = vec2(0.0f, -0.1f);
		vec2 velocity = vec2(0.0f, 0.0f);
		vec2 eye;
		bool is_move = false;
		float time = 0.0f;
		int onBoxNum = -1;
		float invincibility = 0.0f;

	public:
		void draw(bool is_front)
		{
			beginTransformation();
			{
				translate(start_pos);

				/*beginTransformation(); // ������ �ڽ�
				{
					translate(center);
					translate(center_box);
					drawWiredBox(Colors::black, 0.14f, 0.26f);
				}
				endTransformation();*/
				beginTransformation(); // face
				{
					translate(center);
					translate(0.0f, 0.09f);
					drawFilledCircle(Colors::face, 0.04f); // face
					if (is_front == true)
					{
						translate(0.042f, 0.0f);
						drawFilledBox(Colors::face, 0.02f, 0.01f); // nose
						translate(-0.02f, 0.01f);
						drawFilledBox(Colors::olive, 0.0075f, 0.01f); // eye
						translate(0.0015f, -0.02f);
						drawFilledBox(Colors::olive, 0.0075f, 0.005f); // beard
						translate(0.0f, -0.005f);
						drawFilledBox(Colors::olive, 0.02f, 0.0075f); // mouse
						translate(-0.04f, 0.02f);
						drawFilledCircle(Colors::olive, 0.0075f); // ear
						translate(0.0035f, -0.0025f);
						drawFilledCircle(Colors::face, 0.0045f); // ear
					}
					else
					{
						translate(-0.042f, 0.0f);
						drawFilledBox(Colors::face, 0.02f, 0.01f); // nose
						translate(0.02f, 0.01f);
						drawFilledBox(Colors::olive, 0.0075f, 0.01f); // eye
						translate(-0.0015f, -0.02f);
						drawFilledBox(Colors::olive, 0.0075f, 0.005f); // beard
						translate(-0.0f, -0.005f);
						drawFilledBox(Colors::olive, 0.02f, 0.0075f); // mouse
						translate(0.04f, 0.02f);
						drawFilledCircle(Colors::olive, 0.0075f); // ear
						translate(-0.0035f, -0.0025f);
						drawFilledCircle(Colors::face, 0.0045f); // ear
					}
				}
				endTransformation();

				beginTransformation(); // cap
				{
					if (is_front == true)
					{
						translate(center);
						translate(0.0f, 0.14f);
						drawFilledBox(Colors::red, 0.04f, 0.015f);
						translate(0.005f, -0.015f);
						drawFilledBox(Colors::red, 0.085f, 0.015f);
					}
					else
					{
						translate(center);
						translate(0.0f, 0.14f);
						drawFilledBox(Colors::red, 0.04f, 0.015f);
						translate(-0.005f, -0.015f);
						drawFilledBox(Colors::red, 0.085f, 0.015f);
					}
				}
				endTransformation();

				beginTransformation(); // right arm
				{
					translate(center);
					translate(0.05f, 0.0f);
					rotate(30);
					if (is_move == true)
					{
						rotate(-sinf(time*2.0f + 3.141592f) * 40.0f);	// animation!	
					}
					drawFilledBox(Colors::face, 0.03f, 0.07f);
					translate(0.002f, -0.035f);
					drawFilledCircle(Colors::face, 0.014f);
				}
				endTransformation();

				beginTransformation(); // left arm
				{
					translate(center);
					translate(-0.05f, 0.0f);
					rotate(-30);
					if (is_move == true)
					{
						rotate(sinf(time*2.0f + 3.141592f) * 40.0f);	// animation!	
					}
					drawFilledBox(Colors::face, 0.03f, 0.07f);
					translate(-0.002f, -0.035f);
					drawFilledCircle(Colors::face, 0.014f);
				}
				endTransformation();

				beginTransformation(); // body
				{
					translate(center);
					drawFilledBox(Colors::red, 0.1f, 0.1f);
					beginTransformation(); // ����� �ձ۰� ����� ���� �κ�
					{
						translate(-0.045f, 0.05f);
						rotate(45);
						drawFilledTriangle(Colors::white, 0.025f);
						translate(-0.0026f, -0.026f);
						drawFilledCircle(Colors::red, 0.02f);
					}
					endTransformation();
					beginTransformation(); //����� �ձ۰� ����� ���� �κ�
					{
						translate(0.045f, 0.05f);
						rotate(-45);
						drawFilledTriangle(Colors::white, 0.025f);
						translate(0.0026f, -0.026f);
						drawFilledCircle(Colors::red, 0.02f);
					}
					endTransformation();

					translate(-0.025f, 0.0f); // �� �׸��� �κ�
					drawFilledBox(Colors::blue, 0.0125f, 0.1f);
					translate(0.05f, 0.0f);
					drawFilledBox(Colors::blue, 0.0125f, 0.09f);
					translate(-0.025f, -0.025f);
					drawFilledBox(Colors::blue, 0.1f, 0.075f);
					translate(-0.025f, 0.03f);
					drawFilledBox(Colors::yellow, 0.0125f, 0.0125f);
					translate(0.05f, 0.0f);
					drawFilledBox(Colors::yellow, 0.0125f, 0.0125f);
				}
				endTransformation();
				
				if (invincibility > 0.0f) // ������ �� ���� �� ����
				{
					beginTransformation();
					{
						translate(center);
						translate(0.0f, -0.02f);
						drawFilledStar(Colors::yellow, 0.03f, 0.01f);
					}
					endTransformation();
				}

				beginTransformation(); // leftleg
				{
					translate(center);
					if (is_move == true)
					{
						rotate(sinf(time*2.0f + 3.141592f) * 10.0f);	// animation!
					}
					translate(-0.025f, -0.075f);
					drawFilledBox(Colors::olive, 0.025, 0.025f);
					translate(-0.01f, -0.025f);
					drawFilledBox(Colors::olive, 0.05f, 0.025f);
				}
				endTransformation();

				beginTransformation(); // rightleg
				{
					translate(center);
					if (is_move == true)
					{
						rotate(-sinf(time*2.0f + 3.141592f) * 10.0f);	// animation!
					}
					translate(0.025f, -0.075f);
					drawFilledBox(Colors::olive, 0.025, 0.025f);
					translate(0.01f, -0.025f);
					drawFilledBox(Colors::olive, 0.05f, 0.025f);
				}
				endTransformation();
			}
			endTransformation();

			head = center.y - 0.21f; // �������� �Ӹ� ���� ��Ÿ���� �� �Դϴ�.
			foot = center.y - 0.44f; // �������� �߹ٴ���(���� �Ʒ�)�� ��Ÿ���� �� �Դϴ�.
			front = start_pos.x + center.x + 0.07f; // �������� ���� �� �κ��� ��Ÿ���� �� �Դϴ�.
			back = start_pos.x + center.x - 0.07f; // �������� ���� �� �κ��� ��Ÿ���� �� �Դϴ�.
			if (is_front == true) // �������� ���� �� ��, �ڸ� �� �� ���� ��ġ�� ��Ÿ���� �� �Դϴ�.
			{
				eye.x = start_pos.x + center.x + 0.07f;
				eye.y = center.y - 0.24;
			}
			else
			{
				eye.x = start_pos.x + center.x - 0.07f;
				eye.y = center.y - 0.24;
			}
			time += this->getTimeStep();
		}

		void update(const float& dt)
		{
			center += velocity * dt;
		}
	};

	class Mybullet : public Mario
	{
	public:
		vec2 velocity;
		vec2 center;

		Mybullet(vec2 start)
		{
			center = start; // �������� �� ��ġ�� center �� �Դϴ�.
		}

		void draw()
		{
			beginTransformation();
			translate(center);
			drawFilledRegularConvexPolygon(Colors::yellow, 0.015f, 8);
			drawWiredRegularConvexPolygon(Colors::black, 0.015f, 8);
			endTransformation();
		}

		void update(const float& dt)
		{
			center += velocity * dt;
		}
	};

}