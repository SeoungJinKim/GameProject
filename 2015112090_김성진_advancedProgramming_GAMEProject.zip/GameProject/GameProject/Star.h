#pragma once
#include "Game2D.h"

namespace jm
{
	class Star
	{
	public:
		vec2 center;

	public:
		void draw() // ���� �׸��� �κ��Դϴ�.
		{
			beginTransformation();
			{
				drawFilledStar(Colors::gold, 0.06f,0.04f);
			}
			endTransformation();	
		}
		~Star()
		{
		}
	};
}