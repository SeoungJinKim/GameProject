#pragma once
#include "Game2D.h"
#include <cstdlib>
#include <ctime>
#include <random>
#include <cmath>
#include "Box.h"
#include "Star.h"

namespace jm {

	class Map
	{
	public:
		vec2 center = vec2(0.0f, 0.0f);
		vec2 startPos = vec2(-1.7, -0.3f);
		bool flag = false, makeBoxFlag = true, changeFlag = false;
		float boxSize = 0.168f;
		float temp = 0;
		int boxNum = 0;
		Box *boxes[10] = { nullptr, };

		Map()
		{
			srand((unsigned int)std::time(NULL));

			boxNum = rand() % 5 + 3;
			for (int i = 0; i < boxNum; i++)
			{
				makeBoxFlag = true;
				boxes[i] = new Box;
				for (int j = 0; j < i; j++)
				{
					if (pow(fabs(boxes[i]->center.x - boxes[j]->center.x), 2) + pow(fabs(boxes[i]->center.y - boxes[j]->center.y), 2) < 0.24f*0.24f) // �ڽ��� ��ġ�� ��ġ�� �ٽ� ����� ���ؼ� �Դϴ�.
					{
						delete boxes[i]->star;
						delete boxes[i];
						makeBoxFlag = false;
						break;
					}
				}
				if (makeBoxFlag == false) i--;
			}
		}
		~Map()
		{
			for (int i = 0; i < boxNum; i++)
			{
				if (boxes[i] != nullptr)
				{
					if (boxes[i]->star != nullptr) delete boxes[i]->star;
					delete boxes[i];
				}
			}
		}
		void mapDraw() // ���ڸ� �׷��ִ� �κ��Դϴ�.
		{
			beginTransformation();
			{
				translate(center.x, center.y-0.8);
				drawFilledBox(Colors::black, 100.0f, 0.4f);
			}
			endTransformation();
			for (int i = 0; i < boxNum; i++)
			{
				if (boxes[i] != nullptr)
				{
					beginTransformation();
					{
						translate(center);
						translate(boxes[i]->center);
						if (boxes[i]->hit == true)
						{
							drawFilledBox(Colors::gray, boxSize, boxSize);
							if (boxes[i]->delete_star == false)
							{
								beginTransformation();
								{
									translate(vec2(0.0f, 0.133f));
									boxes[i]->star->draw();
								}
							}
							endTransformation();
						}
						else drawFilledBox(Colors::gold, boxSize, boxSize);
					}
					endTransformation();
				}
			}
		}
	};

}